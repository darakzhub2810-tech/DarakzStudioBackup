document.addEventListener("DOMContentLoaded", () => {
  /* -----------------------
     Helper / Utilities
     ----------------------- */
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));
  const safeOpen = (url) => {
    if (!url || url === "#" || url.trim() === "") return;
    window.open(url, "_blank", "noopener");
  };

  function debounce(fn, wait = 250) {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), wait);
    };
  }

  /* -----------------------
     Privacy Popups
     ----------------------- */
  const privacyBtns = $$(".privacy-btn");
  const closeBtns = $$(".close-popup");
  privacyBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const id = btn.dataset.popup;
      const el = document.getElementById(id);
      if (el) el.style.display = "block";
    });
  });
  closeBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      if (btn.parentElement) btn.parentElement.style.display = "none";
    });
  });

  /* -----------------------
     Continue (agree checkbox)
     ----------------------- */
  const checkbox = $("#agreeCheckbox");
  const continueBtn = $("#continueBtn");
  if (checkbox && continueBtn) {
    checkbox.addEventListener("change", () => {
      continueBtn.disabled = !checkbox.checked;
    });
    continueBtn.addEventListener("click", () => {
      const el = document.getElementById("projects-section");
      if (el) el.scrollIntoView({ behavior: "smooth" });
    });
  }

  /* -----------------------
     Card scroll mapping
     ----------------------- */
  const cardScrollMap = {
    shop: "shop-project",
    darakz: "darakz-project",
    hub: "hub-project",
    others: "others-project",
    shirt: "shirt-section",
    hoodie: "hoodie-section",
    sticker: "sticker-section"
  };

  $$(".card").forEach(card => {
    card.addEventListener("click", () => {
      const key = card.dataset.detail;
      const targetId = cardScrollMap[key];
      if (!targetId) return;
      const target = document.getElementById(targetId);
      if (target) target.scrollIntoView({ behavior: "smooth" });
    });
  });

  /* -----------------------
     Scripts Database
     ----------------------- */
  const scriptsDB = [
  {
    name: "Trade Scam - Coming Soon",
    keywords: "trade scam freeze trade-freeze old coming soon rayfield scam",
    desc: "Release Date : 30th November 2025. Stay tuned on Discord for early access.",
    img: "assets/tradescamrayfield.png",
    link: "#"
  },

  {
    name: "Darakz Hub V1.0 (Trade-Freeze)",
    keywords: "trade scam trade-freeze darakz hub v1 freeze scam",
    desc: "Old Version! Trade-Freeze script for Roblox with fast hooking & anti-ban.",
    img: "assets/tradescamv4.png",
    link: "#"
  },

  {
    name: "Fish It Script",
    keywords: "fish it fish auto fishit vikai",
    desc: "Vikai Hub | Auto-fish script for Roblox with fast hooking & anti-ban.",
    img: "assets/fishit.png",
    link: "https://yorurl.com/Darakz-Fish-VikaiHub"
  }
];


  /* -----------------------
     Search logic (FINAL)
     ----------------------- */
  const searchInput = $("#scriptSearch");
  const resultBox = $("#searchResult");

  function doSearch(query) {
    if (!resultBox) return;
    const q = (query || "").trim().toLowerCase();

    if (!q) {
      resultBox.innerHTML = `<p style="color:#bbb;margin:0">Type to search scripts...</p>`;
      return;
    }

    const results = scriptsDB.filter(item => {
      return item.keywords.toLowerCase().includes(q) ||
             item.name.toLowerCase().includes(q);
    });

    if (!results.length) {
      resultBox.innerHTML = `<p>No results found for "<b>${q}</b>"</p>`;
      return;
    }

    resultBox.innerHTML = results.map(item => `
      <div style="padding:15px;margin-bottom:15px;background:#111;border-radius:10px;border:1px solid #ff0000;box-shadow:0 0 10px red;">
        <img src="${item.img}" style="width:100%;border-radius:10px;margin-bottom:10px;">
        <h3>${item.name}</h3>
        <p>${item.desc}</p>
        <a class="download-btn" href="${item.link}" target="_blank">Get Link</a>
      </div>
    `).join("");
  }

  if (searchInput) {
    searchInput.addEventListener("input", debounce(() => {
      doSearch(searchInput.value);
    }, 200));
  }

  // initial render
  if (resultBox) {
    resultBox.innerHTML = `<p style="color:#bbb;margin:0">Type to search scripts...</p>`;
  }
});
